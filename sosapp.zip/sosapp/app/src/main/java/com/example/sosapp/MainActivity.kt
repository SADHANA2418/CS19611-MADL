package com.example.sosapp

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.telephony.SmsManager
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import android.util.Log
import java.util.*

class MainActivity : AppCompatActivity() {

    private lateinit var tts: TextToSpeech
    private var emergencyPhoneNumber = "+919950317550"  // Default phone number
    private var emergencyEmail = "220701235@rajalakshmi.edu.in"  // Default email

    private val SMS_PERMISSION_CODE = 101

    private lateinit var sosButton: Button
    private lateinit var emailButton: Button
    private lateinit var phoneEditText: EditText
    private lateinit var emailEditText: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize TextToSpeech
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts.language = Locale.US
            }
        }

        // Initialize views
        sosButton = findViewById(R.id.sosButton)
        emailButton = findViewById(R.id.emailButton)
        phoneEditText = findViewById(R.id.phoneEditText)
        emailEditText = findViewById(R.id.emailEditText)

        // Set onClickListener for SOS button
        sosButton.setOnClickListener {
            updateEmergencyContactInfo()
            speakSOS()
            sendSOSMessage()
        }

        // Set onClickListener for Email button
        emailButton.setOnClickListener {
            updateEmergencyContactInfo()
            sendEmail()
        }
    }

    // Updates phone and email from EditText if not empty
    private fun updateEmergencyContactInfo() {
        val enteredPhone = phoneEditText.text.toString().trim()
        if (enteredPhone.isNotEmpty()) {
            emergencyPhoneNumber = enteredPhone
        }

        val enteredEmail = emailEditText.text.toString().trim()
        if (enteredEmail.isNotEmpty()) {
            emergencyEmail = enteredEmail
        }
    }

    // Speaks SOS message
    private fun speakSOS() {
        val textToSpeak = "Help me! This is an emergency!"
        tts.speak(textToSpeak, TextToSpeech.QUEUE_FLUSH, null, null)
    }

    // Checks SMS permission
    private fun checkSmsPermission(): Boolean {
        return if (ActivityCompat.checkSelfPermission(
                this, Manifest.permission.SEND_SMS
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this, arrayOf(Manifest.permission.SEND_SMS),
                SMS_PERMISSION_CODE
            )
            false
        } else true
    }

    // Sends SMS to emergency number
    private fun sendSOSMessage() {
        if (!checkSmsPermission()) {
            Toast.makeText(this, "Requesting SMS permission", Toast.LENGTH_SHORT).show()
            return
        }

        try {
            val smsManager = SmsManager.getDefault()
            smsManager.sendTextMessage(
                emergencyPhoneNumber,
                null,
                "SOS! I need help. This is an emergency.",
                null,
                null
            )
            Toast.makeText(this, "SMS sent to $emergencyPhoneNumber", Toast.LENGTH_LONG).show()
            Log.d("SOSApp", "SMS sent to $emergencyPhoneNumber")
        } catch (e: Exception) {
            // Log the error for debugging
            Log.e("SOSApp", "SMS failed: ${e.message}")
            Toast.makeText(this, "SMS failed: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    // Sends email to emergency contact
    private fun sendEmail() {
        val emailIntent = Intent(Intent.ACTION_SENDTO).apply {
            data = Uri.parse("mailto:$emergencyEmail")
            putExtra(Intent.EXTRA_SUBJECT, "EMERGENCY! SOS!")
            putExtra(Intent.EXTRA_TEXT, "Please help me. This is an SOS alert.")
        }

        try {
            startActivity(Intent.createChooser(emailIntent, "Send email..."))
        } catch (e: Exception) {
            Toast.makeText(this, "No email client installed.", Toast.LENGTH_SHORT).show()
        }
    }

    // Handles permission result
    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == SMS_PERMISSION_CODE && grantResults.isNotEmpty()
            && grantResults[0] == PackageManager.PERMISSION_GRANTED
        ) {
            sendSOSMessage() // Retry if permission granted
        } else {
            Toast.makeText(this, "SMS permission denied", Toast.LENGTH_SHORT).show()
        }
    }

    // Release TTS resources
    override fun onDestroy() {
        if (::tts.isInitialized) {
            tts.stop()
            tts.shutdown()
        }
        super.onDestroy()
    }
}
